# Multiplikation
multipliziere <- function(x,y) {
  return(x*y)
}